import VerticalNavbar from './components/VerticalNavbarComponent'
import useVerticalNavbarController from './components/useVerticalNavbarController'
export { useVerticalNavbarController }
export default VerticalNavbar
