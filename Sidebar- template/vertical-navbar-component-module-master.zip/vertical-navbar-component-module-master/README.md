# Vertical Navbar
Vertical Navbar is a react component that creates a 
vertical navbar in the left side of the page. 
It behaves completely responsive when accessing it in small devices
transforming the vertical navbar to a horizontal navbar at the bottom of the page.

[Documentation](https://redwallsolutions.github.io/vertical-navbar-component-module)
