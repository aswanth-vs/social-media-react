export default {
	typescript: true,
	ignore: ['README.md'],
	base: '/vertical-navbar-component-module/',
	dest: 'demo/output'
}
